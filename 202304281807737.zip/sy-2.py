#猜数游戏
import random

def guess_number():
    num = random.randint(1, 100)
    while True:
        try:
            guess = int(input('请输入一个1~100之间的整数：'))
            if guess == num:
                print('恭喜您，猜对了！')
                break
            elif guess < num:
                print('您猜的数字小了，请再次尝试。')
            else:
                print('您猜的数字大了，请再次尝试。')
        except ValueError:
            print('请您输入一个有效的整数！')

guess_number()
