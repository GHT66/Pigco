from random import randint
def guess (maxValue=10000000000000,maxTimes=1):
    value = randint(1,maxValue)
    for i in range (maxTimes):
        prompt = '开始猜数:' if i==0 else'请重新输入:'
        try:
            x=int(input(prompt))
        except:
            print('必需输入一个数介于1和',maxValue)
        else:
            if x == value:
                print('猜对了！')
                break
            elif x > value:
                print('太大了')
            else :
                print('太小了')
    else:
            print('错误，游戏结束！')
            print('正确答案是：',value)
guess()
        
                
