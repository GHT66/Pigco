class Person():
    #定义学员的属性
    def __init__(self,name,weight):
        self.name=name
        self.weight=weight
    def run(self):
        self.weight-=0.5
 
    def eat(self):
        self.weight+=1
 
xiaoming=Person('小明',50)
 
print("姓名：",xiaoming.name)     
 
xiaoming.eat()
print("体重：",xiaoming.weight)

xiaoming.run()
print("体重：",xiaoming.weight)
