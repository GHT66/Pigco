import random
#创建data.txt写入随机整数
with open("data.txt", "w") as fp:
    for i in range(10):
        num = random.randint(1, 100)
        fp.write(str(num) + "\n")

# 读取文件并返回列表
with open("data.txt", "r") as fp:
    lines = [line.rstrip() for line in fp.readlines()]

# 竖向输出结果
output_str = "\n".join(lines) + "\n"
print(output_str)

