x=range(1,100,2)

print('1+3+5+...+100=',sum(range(1,100,2)))
n=input('请输入如一个三位数：')
a,b,c=map(int,n)
print(a,b,c)
s=0
for i in range(1,100,2):
   s+= (i*i)
print('1^2+3^2+5^2+....99^2=',sum(i**2 for i in range(1,100,2)))
