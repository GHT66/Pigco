x=int(input('请输入一个三位数：'))
a=x//100
b=(x//10)%10
c=x%10
#x= input()
#a,b,c=map(int,x)
print(a,b,c)
