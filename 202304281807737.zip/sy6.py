person_infos=[]
def print_menu():
        print("--" * 20)
        print('''系统提供以下功能
        1：添加联系人信息
        2：删除联系人信息
        3：修改联系人信息
        4：查询指定联系人信息
        5: 显示全部联系人信息
        6：退出通讯录''')
        print("--" * 20)
def add_info():
    # 提示并获取联系人的姓名
    new_name = input("请输入新增联系人名字：")
    # 提示并获取联系人手机号码
    new_phone = input("请输入新增联系人的手机号码：")
    # 提示并获取联系人地址
    new_addr = input("请输入新增联系人的地址")
    new_infos = {}  # 字典是可变对象，初始化一定不能放在for循环前面
    new_infos['name'] = new_name
    new_infos['phone'] = new_phone
    new_infos['addr'] = new_addr
    person_infos.append(new_infos)
def del_info():
        
    del_num = int(input("请输入要删除的序号：")) 
    del person_infos[del_num]
def modify_info():
        student_id = int(input("请输入要修改的联系人的序号："))
        new_name = input("请输入联系人修改后的新名字：")
        new_phone = input("请输入联系人修改后的新手机号码：")
        new_addr = input('请输入联系人修改后的新地址：')
        person_infos[student_id]['name'] = new_name
        person_infos[student_id]['phone'] = new_phone
        person_infos[student_id]['addr'] = new_addr
def search_info():
        name = (input('请输入要搜索的联系人姓名：'))
        for temp in person_infos:
            for key,value in temp.items():
                if value ==name:
                    print('联系人 %s 的电话号码是 %s , 地址%s'%(temp['name'],temp['phone'],temp['addr']))
                    break
def show_infos():
        print("--" * 20)
        print("学生的信息如下:")
        print("--" * 20)
        print("序号      姓名      手机号码       地址")
        i = 0
        for temp in person_infos:
            print("%d      %s      %s       %s" % (i, temp['name'], temp['phone'], temp['addr']))
            i += 1
def main():
        while True:
            print_menu()        # 打印菜单
            key = input("请输入功能对应的数字:")  # 获得用户输入的序号
            if key == '1':     # 添加联系人的信息
                add_info()
            elif key == '2':  # 删除联系人的信息
                del_info()
            elif key == '3':  # 修改联系人的信息
                modify_info()
            elif key == '4':  # 查看指定联系人的信息
                search_info()
            elif key == '5':  # 查看所有联系人的信息
                show_infos()
            elif key == '6':  # 退出管理器
                quit_confirm = input("亲，真的要退出么？(Yes or No):")
                if quit_confirm == "Yes":
                    break      # 结束循环
                else:
                    print('输入有误，请重新输入')
main()
