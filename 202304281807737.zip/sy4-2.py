num=int(input('请输入一个大于2的整数：'))
for n in range(num,1,-1):
    for i in range(2,n):
        if n%i==0:
            n=0
        else:
             return n
    print(n)



    
        
