from managerSystem import ContactManager
#启动管理系统
if __name__=='__main__':
    contact_manager=ContactManager()
    contact_manager.run()
from contact import Contact
class ContactManager(object):
    def __int__(self):
        self.contact_list=[]
    def run(self):
        self.load_contact()
        while True:
            self.show_menu()
            menu_num=int(input('请输入您需要的功能序号:'))
            if menu_num==1:
                self.add_contact()
            elif menu_num==2:
                self.del_contact()
            elif menu_num==3:
                self.modify_contact()
            elif menu_num==4:
                self.search_contact()
            elif menu_num==5:
                self.show_contact()
            elif menu_num==6:
                self.save_contact()
            elif menu_num==7:
                break
    @staticmethod
    def show_menu():
        print('请选择如下功能：')
        print('1、添加联系人')
        print('2、删除联系人')
        print('3、修改联系人信息')
        print('4、查询联系人信息')
        print('5、显示所有联系人信息')
        print('6、保存联系人信息')
        print('7、退出系统')
 
    def add_contact(self):
        name = input('请输入您的姓名：')
        gender = input('请输入您的性别：')
        tel = input('请输入您的电话：')
        contact = Contact(name, gender, tel)
        self.contact_list.append(contact)
        print(self.contact_list)
        print(contact)
 
    def del_contact(self):
        del_name = input('请输入要删除的联系人姓名：')
        flag=1
        for i in self.contact_list:
            if i.name == del_name:
                self.contact_list.remove(i)
                flag=0
                break
        if flag==1:
            print('查无此人！')
 
            print(self.contact_list)
 
    def modify_contact(self):
        modify_name = input('请输入要修改的联系人姓名：')
        flag=1
        for i in self.contact_list:
            if i.name == modify_name:
                i.name = input('请输入联系人姓名：')
                i.gender = input('请输入联系人性别：')
                i.tel = input('请输入联系人手机号：')
                print(f'修改该联系人信息成功，姓名：{i.name}, 性别{i.gender}, 手机号{i.tel}')
                flag=0
                break
        if flag==1:
            print('查无此人！')
    def search_contact(self):
        search_name = input('请输入要查询的联系人姓名：')
        flag=1
        for i in self.contact_list:
            if i.name == search_name:
                print(f'姓名{i.name}, 性别{i.gender}, 手机号{i.tel}')
                flag=0
                break
        if flag==1:
            print('查无此人！')
 
    def show_contact(self):
        print("姓名\t性别\t手机号")
        for i in self.contact_list:
            print(f'{i.name}\t{i.gender}\t{i.tel}')
 
    def save_contact(self):
        f = open('contact.data', 'w')
        new_list = [i.__dict__ for i in self.contact_list]
        f.write(str(new_list))
        f.close()
 
 
    def load_contact(self):
        try:
            f = open('contact.data', 'r')
        except:
            f = open('contact.data', 'w')
        else:
            data = f.read()
            new_list = eval(data)
            self.contact_list = [Contact(i['name'], i['gender'], i['tel']) for i in new_list]
        finally:
            f.close()
main()

