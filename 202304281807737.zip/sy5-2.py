from random import randint
def guess (maxValue=100,maxTimes=5):
    value = randint(1,maxValue)
    for i in range (maxTimes):
        print('开始猜数：')
        x=int(input())
        
        if x == value:
            print('猜对了！')
            break
        elif x > value:
            print('太大了')
        else :
            print('太小了')
    else:
            print('错误，游戏结束！')
            print('正确答案是：',value)
guess()
        
