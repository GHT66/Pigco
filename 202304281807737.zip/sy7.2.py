class Admin:
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def login(self):
        input_username = input('请输入账号：')
        input_password = input('请输入密码：')
        if self.username == input_username and self.password == input_password:
            print('登录成功')
            self.change_password()
        else:
            print('登录失败')

    def change_password(self):
        new_username = input('请输入新的账号：')
        new_password = input('请输入新的密码：')
        self.username = new_username
        self.password = new_password
        print('修改成功')
        print('新的账号和密码为：', self.username, self.password)


admin = Admin('admin', '123')
admin.login()
