
s = 0
for i in range(1,100,2):
   s += i
print('1+3+5+.....100=',s)
  

